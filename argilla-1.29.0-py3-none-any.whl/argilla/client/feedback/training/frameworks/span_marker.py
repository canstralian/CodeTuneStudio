#  Copyright 2021-present, the Recognai S.L. team.
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.

from typing import TYPE_CHECKING

from datasets import DatasetDict

from argilla.client.feedback.training.base import ArgillaTrainerSkeleton
from argilla.client.models import TokenClassificationRecord
from argilla.training.span_marker import ArgillaSpanMarkerTrainer as ArgillaSpanMarkerTrainerV1

if TYPE_CHECKING:
    from argilla.client.feedback.integrations.huggingface.model_card import FrameworkCardData


class ArgillaSpanMarkerTrainer(ArgillaSpanMarkerTrainerV1, ArgillaTrainerSkeleton):
    def __init__(self, *args, **kwargs) -> None:
        ArgillaTrainerSkeleton.__init__(self, *args, **kwargs)

        import torch
        from span_marker import SpanMarkerModel

        self.trainer_model = None

        self.device = "cpu"
        if torch.backends.mps.is_available():
            self.device = "mps"
        elif torch.cuda.is_available():
            self.device = "cuda"

        if self._seed is None:
            self._seed = 42

        if self._model is None:
            self._model = "bert-base-cased"

        if isinstance(self._dataset, DatasetDict):
            self._train_dataset = self._dataset["train"]
            self._eval_dataset = self._dataset["test"]
        else:
            self._train_dataset = self._dataset
            self._eval_dataset = None

        if self._record_class == TokenClassificationRecord:
            self._column_mapping = {"text": "text", "token": "tokens", "ner_tags": "ner_tags"}
            self._label_list = self._train_dataset.features["ner_tags"].feature.names

            self._model_class = SpanMarkerModel
        else:
            raise NotImplementedError("Text2TextRecord and TextClassification are not supported.")

        self.init_training_args()

    def get_model_card_data(self, **card_data_kwargs) -> "FrameworkCardData":
        raise NotImplementedError(
            "This method has to be implemented after `FeedbackDataset` allows for token classification."
        )

    def push_to_huggingface(self, repo_id: str, **kwargs) -> None:
        raise NotImplementedError(
            "This method has to be implemented after `FeedbackDataset` allows for token classification."
        )
